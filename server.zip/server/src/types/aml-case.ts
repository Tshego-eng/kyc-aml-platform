export type CaseDecision =
  | "CONTINUE_INVESTIGATION"
  | "FALSE_POSITIVE"
  | "RESOLVE"
  | "ESCALATE"
  | "REGULATORY_REPORT";